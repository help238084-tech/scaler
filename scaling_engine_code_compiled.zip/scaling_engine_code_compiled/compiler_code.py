from scripts.internal_configs import default_configs
print("start of import modules")
import threading
import math
from pynput import keyboard as kb
import numpy as np
import json
import time
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo
from scripts.chrome_focus_guard import ChromeFocusGuard
# Third-party
import pandas as pd
import sys
import os
import math

from scripts.basic_functions_variables import (concater,

                                               read_df_custom, save_df_custom)
    # -----------------------------
# load config
# -----------------------------
config_dir = Path("config")
chosen_config = "user_config.json"
config_path = config_dir / chosen_config

with config_path.open("r", encoding="utf-8") as f:
    config = json.load(f)

run_tag  = config ['run_tag']
print("run_tag ",run_tag)
data_dir = Path(f"data/{run_tag}")
all_prompts_dir =  data_dir / "all_prompts"
active_prompt_dir = data_dir/ "active_prompt"
input_data_dir  = data_dir / "input_data"
output_data_dir = data_dir/ "output_data"

master_dataset =  read_df_custom(input_data_dir,"master_dataset")


ori_to_pp_ccp_notes =  read_df_custom(output_data_dir,"ori_to_pp_ccp_notes")
monthly_ccp_notes =  read_df_custom(output_data_dir,"monthly_ccp_notes")
ccp_notes_with_issues =  read_df_custom(output_data_dir,"ccp_notes_with_issues")

relevant_ccp_notes = list(set(master_dataset['ccp_notes']))
ori_to_pp_ccp_notes_fil = ori_to_pp_ccp_notes[ori_to_pp_ccp_notes['ccp_notes'].isin(relevant_ccp_notes)]
ori_to_pp_ccp_notes_fil.drop_duplicates(inplace=True)

relevant_ccp_notes_pp = list(set(ori_to_pp_ccp_notes_fil['ccp_notes_pp']))
monthly_ccp_notes_fil = monthly_ccp_notes[monthly_ccp_notes['ccp_notes_pp'].isin(relevant_ccp_notes_pp)]
monthly_ccp_notes_fil.drop_duplicates(inplace=True)

relevant_ccp_notes_cleaned = list(set(monthly_ccp_notes_fil['ccp_notes_cleaned']))
ccp_notes_with_issues_fil = ccp_notes_with_issues[ccp_notes_with_issues['ccp_notes_cleaned'].isin(relevant_ccp_notes_cleaned)]
ccp_notes_with_issues_fil.drop_duplicates(inplace=True)


save_df_custom(ori_to_pp_ccp_notes_fil,data_dir / "compiler_output","ori_to_pp_ccp_notes_fil",False)
save_df_custom(monthly_ccp_notes,data_dir / "compiler_output","monthly_ccp_notes_fil",False)
save_df_custom(ccp_notes_with_issues,data_dir / "compiler_output","ccp_notes_with_issues_fil",False)