from redaction_utility import main

if __name__ == "__main__":
    main()