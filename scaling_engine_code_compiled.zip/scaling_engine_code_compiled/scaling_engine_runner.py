import scaling_engine

if __name__ == "__main__":
    from multiprocessing import freeze_support
    freeze_support()
    scaling_engine.main()