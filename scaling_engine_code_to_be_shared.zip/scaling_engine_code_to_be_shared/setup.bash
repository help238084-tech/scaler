@Echo off
SETLOCAL ENABLEDELAYEDEXPANSION

echo ============================================================
echo  Complaints Usecase Environment Setup
echo ============================================================
echo.

:: ---------------------------------------------------------------
:: STEP 1: Write .condarc to user home directory
:: ---------------------------------------------------------------
echo [1/5] Writing .condarc configuration...

set "CONDARC_PATH=%USERPROFILE%\.condarc"

(
echo channels:
echo  - https://artifactory.aexp.com/anaconda-group/pkgs/main/
echo  - https://artifactory.aexp.com/anaconda-group/pkgs/free/
echo  - https://artifactory.aexp.com/anaconda-group/pkgs/r/
echo  - https://artifactory.aexp.com/anaconda-group/pkgs/pro/
echo  - https://artifactory.aexp.com/anaconda-group/pkgs/msys2/
echo  - https://artifactory.aexp.com/anaconda-group/pkgs/mro/
echo  - https://artifactory.aexp.com/anaconda-group/pkgs/archive/
echo  - https://artifactory.aexp.com/anaconda-group/pkgs/mro-archive/
echo  - https://artifactory.aexp.com/anaconda-group/conda-forge
echo  - https://artifactory.aexp.com/anaconda-group/gpuopenanalytics/label/dev
echo auto_activate_base: true
echo ssl_verify: false
echo.
echo default_channels:
echo  - https://ci-repo.aexp.com/repository/anaconda-group/pkgs/main/
echo  - https://ci-repo.aexp.com/repository/anaconda-group/pkgs/free/
echo  - https://ci-repo.aexp.com/repository/anaconda-group/pkgs/r/
echo  - https://ci-repo.aexp.com/repository/anaconda-group/pkgs/pro/
echo  - https://ci-repo.aexp.com/repository/anaconda-group/pkgs/msys2/
echo  - https://ci-repo.aexp.com/repository/anaconda-group/pkgs/mro/
echo  - https://ci-repo.aexp.com/repository/anaconda-group/pkgs/archive/
echo  - https://ci-repo.aexp.com/repository/anaconda-group/pkgs/mro-archive/
) > "%CONDARC_PATH%"

echo    Written to: %CONDARC_PATH%
echo.

:: ---------------------------------------------------------------
:: STEP 2: Configure pip to use Artifactory
:: ---------------------------------------------------------------
echo [2/5] Configuring pip to use Artifactory...

pip config set global.index-url https://artifactory.aexp.com/api/pypi/pypi/simple
pip config set global.index https://artifactory.aexp.com/api/pypi/pypi/simple

echo.

:: ---------------------------------------------------------------
:: STEP 3: Initialise conda for use in batch scripts
:: ---------------------------------------------------------------
echo [3/5] Initialising conda...

:: Try common Anaconda/Miniconda install locations
set "CONDA_SCRIPT="
if exist "%USERPROFILE%\anaconda3\Scripts\activate.bat"   set "CONDA_SCRIPT=%USERPROFILE%\anaconda3\Scripts\activate.bat"
if exist "%USERPROFILE%\miniconda3\Scripts\activate.bat"  set "CONDA_SCRIPT=%USERPROFILE%\miniconda3\Scripts\activate.bat"
if exist "C:\ProgramData\anaconda3\Scripts\activate.bat"  set "CONDA_SCRIPT=C:\ProgramData\anaconda3\Scripts\activate.bat"
if exist "C:\ProgramData\miniconda3\Scripts\activate.bat" set "CONDA_SCRIPT=C:\ProgramData\miniconda3\Scripts\activate.bat"

if "!CONDA_SCRIPT!"=="" (
    echo ERROR: Could not locate conda activate.bat.
    echo        Please open Anaconda Prompt manually and re-run this script,
    echo        or set the CONDA_SCRIPT variable at the top of this file.
    pause
    exit /b 1
)

call "!CONDA_SCRIPT!" base
echo    Conda base activated using: !CONDA_SCRIPT!
echo.

:: ---------------------------------------------------------------
:: STEP 4: Create the conda environment
:: ---------------------------------------------------------------
echo [4/5] Creating conda environment: complains_usecase_env (Python 3.11)...

call conda create -n complains_usecase_env python=3.11 -y
if errorlevel 1 (
    echo ERROR: Failed to create conda environment.
    pause
    exit /b 1
)

call conda activate complains_usecase_env
echo    Environment activated.
echo.

:: ---------------------------------------------------------------
:: STEP 5: Install pip packages
:: ---------------------------------------------------------------
echo [5/5] Installing pip packages...

set "PROJECT_DIR=C:\Users\ssin276\OneDrive - American Express\scaling_engine_v2"
cd /d "%PROJECT_DIR%"
if errorlevel 1 (
    echo WARNING: Could not cd to project directory: %PROJECT_DIR%
    echo          Continuing with package installation from current directory.
    echo.
)

pip install aiohttp pyopenssl pyautogui markdownify openpyxl pynput pdfplumber PyPDF2 xlrd
if errorlevel 1 (
    echo ERROR: Failed to install one or more packages.
    pause
    exit /b 1
)

pip install safechain==1.5.0
if errorlevel 1 (
    echo ERROR: Failed to install safechain.
    pause
    exit /b 1
)

:: ---------------------------------------------------------------
:: Done
:: ---------------------------------------------------------------
echo.
echo ============================================================
echo  Setup complete!
echo  Environment  : complains_usecase_env
echo  Project dir  : %PROJECT_DIR%
echo ============================================================
echo.
pause