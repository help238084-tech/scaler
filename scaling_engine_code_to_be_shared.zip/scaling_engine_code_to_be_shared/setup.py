from setuptools import setup, Extension
from Cython.Build import cythonize
import glob
import os

# 1. Separate the top-level scripts into their own extensions.
# This fixes the "Multiple cython sources" warning.
extensions = [
    Extension("scaling_engine", ["scaling_engine.py"]),
    Extension("redaction_utility", ["redaction_utility.py"]),
]

# 2. Dynamically gather the scripts
for py_file in glob.glob("scripts/*.py"):
    # Skip __init__.py to prevent the module naming crash we saw originally
    if "__init__.py" in py_file:
        continue
    
    # 3. CRITICAL FIX: Replace BOTH forward slashes and backslashes with dots.
    # This ensures it works perfectly on Windows.
    mod_name = os.path.splitext(py_file.replace("\\", ".").replace("/", "."))[0]
    
    extensions.append(Extension(mod_name, [py_file]))

# 4. Compile
setup(
    ext_modules=cythonize(extensions, compiler_directives={"language_level": "3"}),
)